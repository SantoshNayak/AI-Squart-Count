let video = document.getElementById("video");
let model;
// let canvas = document.getElementById("canvas");
// let ctx = canvas.getContext("2d");
let windowHeight = window.outerHeight * 0.4;
let windowWidth = window.outerWidth - 100;

var targetCount = 10;
const detectorConfig = {
  modelType: poseDetection.movenet.modelType.SINGLEPOSE_LIGHTNING,
};

// Hacks for Mobile Safari
video.setAttribute("playsinline", true);
video.setAttribute("controls", true);
setTimeout(() => {
  video.removeAttribute("controls");
});

var tiles_now = 0;
var tiles_previous = 0;
var person_height= 0;
var isHeightAssigned = false;


var upValue = 150;
var downValue = 130;

var threshHoldKneeAnkleDistance = 30;
let detector;

var canCountIncrease = false;
var countValue = 0;
const setupCamera = () => {
  navigator.mediaDevices
    .getUserMedia({
      video: { width: windowWidth, height: windowHeight },
      audio: false,
    })
    .then((stream) => {
      video.srcObject = stream;
      // document.getElementById("targetCount").innerHTML = targetCount;
    });
};

const detectPose = async () => {
  // alert(document.getElementById("video").offsetWidth)
  const poses = await detector.estimatePoses(document.querySelector("video"));

  // const predictions = await model.estimateHands(document.querySelector("video"));
  console.log(poses);

  if (poses.length) {
    let right_shoulder = poses[0].keypoints.find(
      (x) => x.name == "right_shoulder"
    );
    let right_wrist = poses[0].keypoints.find((x) => x.name == "right_wrist");

    let right_knee = poses[0].keypoints.find((x) => x.name == "right_knee");
    let right_ankle = poses[0].keypoints.find((x) => x.name == "right_ankle");

    if (
      right_shoulder.score > 0.5 &&
      right_wrist.score > 0.5 &&
      right_knee.score > 0.5 &&
      right_ankle.score > 0.5
    ) {
      var rightShoulderToAnkleDistance = distanceBetweenTwo(
        right_shoulder.x,
        right_ankle.x,
        right_shoulder.y,
        right_ankle.y
      );

      tiles_now = (257.57 - rightShoulderToAnkleDistance) / 16.036;

      document.getElementById(
        "rightShoulderToAnkleDistance"
      ).innerHTML = rightShoulderToAnkleDistance;
      document.getElementById("tilesAway").innerHTML = tiles_now;

      //track for distance change using tiles_now and tiles_previous variable

      //initially assign height once whole body is visible
      if(!isHeightAssigned){

        tiles_previous = Math.floor(tiles_now)
isHeightAssigned= true
      }
    
      if(tiles_now == Math.floor(tiles_previous)){
        //person is at a constant distance and we can assign our height
        person_height = rightShoulderToAnkleDistance;
        document.getElementById(
          "personHeight"
        ).innerHTML = person_height;
        
      }else{
        //update the previous height as person moved to other distance
        tiles_previous = Math.floor(tiles_now)
      }
    }
  }
};

setupCamera();
video.addEventListener("loadeddata", async () => {
  // document.getElementById("video").offsetWidth, document.getElementById("video").offsetHeight

  const queryString = window.location.search;
  const urlParams = new URLSearchParams(queryString);
  if (urlParams.get("goal")) {
    targetCount = urlParams.get("goal");
  }
  document.getElementById("targetCount").innerHTML = targetCount;

  detector = await poseDetection.createDetector(
    poseDetection.SupportedModels.MoveNet,
    detectorConfig
  );

  document.getElementById("loadingText").innerHTML =
    "Please stand in front of camera";

  setInterval(detectPose, 30);
});

function sendMessagetoFlutter(value) {
  console.log(value);
  // window.CHANNEL_NAME.postMessage('Hello from JS');
}

function distanceBetweenTwo(x2, x1, y2, y1) {
  var a = x2 - x1;
  var b = y2 - y1;

  return Math.sqrt(a * a + b * b);
}
